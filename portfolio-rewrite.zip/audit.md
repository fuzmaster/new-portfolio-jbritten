# Ruthless Portfolio Audit — Jacob Britten

## Executive Summary

Your portfolio is **not bad**. That's the most dangerous place to be — it's competent enough to not embarrass you, but not sharp enough to make a hiring manager stop scrolling. You've built a dark-mode "control room" aesthetic that lands somewhere between "senior engineer" and "sci-fi movie prop." The bones are solid. The execution has gaps that undermine the credibility you're trying to project.

**Lighthouse scores confirm the structural work is there** — 0ms TBT, 0 CLS, decent Speed Index. But your LCP is **89.5 seconds**. That's not a typo. Your hero images are unoptimized PNGs being served at full resolution (3100×2416, 3392×2356, 3680×2688) with `loading="eager"`. That single problem alone would make any technical recruiter question whether you actually understand the systems you claim to build.

---

## Part 1: Visual Brutality

### What Works
- The dark + cyan color system is cohesive and memorable
- The bento grid metrics section is well-structured
- Corner bracket details on the video wrapper are a nice HUD touch
- Typography hierarchy (clamp-based scaling) is competent

### What Doesn't

**1. The hero is doing too much and saying too little.**
You have: a background image, an overlay, a grid overlay, an eyebrow with blinking cursor, a headline, a subtitle, a 3-panel image grid with corner brackets, a HUD bar, AND a scroll indicator. That's 9 visual layers fighting for attention. A senior portfolio should have one dominant visual move, not a buffet. The "reel grid" showing screenshots of Notion boards and code editors is visually flat — they're small, desaturated, and hard to parse at thumbnail scale.

**2. Trust badges look afterthought-y.**
The "Built systems for:" row uses logos at inconsistent visual weights. The CrushIt logo needs a brightness invert filter that makes it look hacked together. Three logos is not enough to justify a trust strip — it highlights the thinness rather than building credibility.

**3. Profile section uses an SRT test screenshot instead of a headshot.**
This is the "About" section. The human being should be here. A terminal output screenshot where your face should be reads as either an oversight or a deliberate avoidance of personal connection. Either way, it hurts.

**4. The "How I Work" section images are mixed quality.**
Camera1.jpg (Blackmagic camera) is a real photo — good. But then you alternate with SVG diagrams (youtube-growth.svg, ai-pipeline.svg) that are likely placeholder-quality. Mixing real photography with synthetic diagrams creates visual dissonance.

**5. Case study cards all link to work.html with identical CTAs.**
Three "VIEW CASE STUDY ↗" links all going to the same page, with no individual anchors. It looks lazy.

**6. Social proof logos appear twice** — once in the trust badges row and again in a dedicated social proof section. Redundant.

---

## Part 2: UX Takedown

**1. Navigation confusion.**
The nav has: WORK, THE LAB, METRICS, STACK, ABOUT, CONTACT, and RESUME. Seven items. "THE LAB" is a separate page; everything else is an anchor on the homepage. A recruiter clicking "WORK" gets scrolled to a preview section, not to your case studies. The disconnect between "WORK" (anchor) and "THE LAB" (page) is confusing.

**2. No direct email/contact path.**
The CTA card says "Book a call ↗" linking to Calendly, plus a duplicate "BOOK A CALL" button below it. There's a LinkedIn link but no email option. Some hiring managers want to email. You're forcing a single funnel.

**3. Lab page is orphaned.**
No navbar, no navigation back except a text link. No footer. If someone lands here directly (shared link), they have no site context.

**4. Resume download has no preview.**
The resume button downloads a PDF with no indication of what they'll get. Consider offering both download and a preview/view option.

**5. Endorsements section is weak.**
Three testimonials, all from Lamacchia Realty colleagues. The quotes praise work ethic ("works quickly," "handles large amounts of projects") — these are junior-level compliments. None speak to the systems-architecture narrative you're building. "Video editor and drone pilot" actively undermines your positioning as a content systems architect.

---

## Part 3: Technical Beatdown

### Performance (Critical)

**1. Image sizes are catastrophic.**
- `notion-pipeline.png`: 3100×2416 pixels, served as PNG, loaded TWICE (hero + case studies)
- `remotion-code.png`: 3392×2356 pixels, same double-load pattern
- `srt-tests.png`: 3680×2688 pixels, used in case studies AND the profile section
- `youtube-growth.png`: 3132×1778 pixels

These should be WebP, resized to max 1200px wide, and served via `srcset` with responsive sizes. The `<picture>` elements you have are pointless — they specify `<source>` with the same PNG format.

**2. LCP of 89.5 seconds.**
Directly caused by the above. Your hero images load eagerly at multi-megapixel resolution.

**3. Same images loaded multiple times.**
`notion-pipeline.png` appears in the hero reel grid AND the case studies grid. Browser caching helps somewhat, but the DOM weight is unnecessary.

### HTML Issues

**1. `&nbsp;` in the `<title>` tag.**
```html
<title>Jacob Britten&nbsp;|&nbsp;Content Systems &amp; AI Pipelines</title>
```
Non-breaking spaces in title tags are semantically wrong and can look weird in browser tabs.

**2. Inline styles on hero background.**
```html
<div class="hero-bg" style="background-image: url('images/Extra/photostoreview-10.jpg');"></div>
```
Move to CSS. Inline styles are a code smell in a portfolio claiming architectural expertise.

**3. Lab page missing favicon, OG tags, and shared nav.**
The lab.html has no `<link rel="icon">`, no OG meta tags, and no navbar. It's a second-class citizen.

**4. `aria-hidden="true"` on nav-links at page load.**
This hides the navigation from screen readers until JavaScript runs. If JS fails, the nav is permanently invisible to assistive technology.

### CSS Issues

**1. Inter font is listed in the "NEVER use" category of the frontend design guidelines.**
The skill doc explicitly calls out Inter as generic AI-slop. For a portfolio projecting senior-level design taste, you need a more distinctive choice.

**2. Duplicate/conflicting transition declarations.**
```css
.card {
  transition: transform 0.2s ease, border-color 0.2s ease;
  transition: opacity 0.6s var(--ease-expo), transform 0.6s var(--ease-expo), border-color 0.3s;
}
```
The second `transition` property completely overwrites the first. This is a copy-paste bug.

**3. `dvh` unit without fallback.**
```css
.hero { min-height: 82dvh; }
```
`dvh` has good support now but older browsers will ignore this entirely, collapsing the hero. Add a `vh` fallback.

**4. `--cyan` inconsistency.**
Your tokens define `--cyan: #00FFC8` but throughout CSS you hard-code `#00FFC8`, `rgba(0,229,255,...)` (which is `#00E5FF`, a DIFFERENT color), and `rgba(0,255,200,...)` (which IS `#00FFC8`). So you're actually using TWO different cyan colors interchangeably. Pick one and use the variable.

**5. `.social-proof` padding declared twice.**
Once at `padding: 3rem 0;` in the main section styles, then again identically in the social proof block.

### JavaScript Issues

**1. No error boundaries.**
The entire script is wrapped in a single `DOMContentLoaded` callback with no try/catch. If any element is missing (e.g., navbar removed for a variant), every subsequent feature breaks.

**2. Hero parallax targets a non-existent element.**
```javascript
const heroVideo = document.querySelector('.hero-bg-video');
```
Your HTML has no `.hero-bg-video` element — it uses a background image. This code runs silently and does nothing.

**3. Stagger bento observer double-observes.**
The bento cards are already observed by the main `allInview` observer AND a separate `bentoObs`. The first one to fire wins, making the second observer's stagger logic unreliable.

---

## Part 4: Specific Fixes (Summary)

| Issue | Fix |
|---|---|
| 89.5s LCP | Convert all images to WebP, resize to ≤1200px, use responsive `srcset` |
| Hero complexity | Remove grid overlay, simplify to 1-2 visual layers |
| Inter font | Switch to a distinctive typeface pair |
| Duplicate images | Load each image once, reference via CSS or lazy-load clones |
| `&nbsp;` in title | Use plain spaces or `—` dash |
| Inline hero bg style | Move to CSS |
| Duplicate `transition` on `.card` | Remove the first declaration |
| Two different "cyan" values | Standardize on one value via `--cyan` variable |
| Missing headshot | Add a real portrait photo in the profile section |
| Lab page missing nav/meta | Add shared navbar component and OG tags |
| Trust logos appearing twice | Remove the duplicate social proof section |
| Endorsements undermining positioning | Replace drone-pilot quote with one that speaks to systems thinking |
| `dvh` without fallback | Add `min-height: 82vh;` before `min-height: 82dvh;` |
| No contact email | Add an email option alongside Calendly |
| JS double-observation of bento cards | Remove from main observer, keep only stagger observer |

---

## Part 5: Image & Visual Asset Specifications

For the rewrite, create/source the following assets and place them in `/images/`:

1. **`hero-bg.webp`** — Your existing desk/workspace photo, converted to WebP, cropped to 1920×1080, compressed to ~150KB
2. **`headshot.webp`** — Professional headshot or environmental portrait. Blurred background, warm lighting, clean framing. 800×800 minimum.
3. **`notion-pipeline.webp`** — Your Notion pipeline screenshot, resized to 1200×936, WebP, ~80KB
4. **`remotion-code.webp`** — Code editor screenshot, resized to 1200×834, WebP, ~80KB
5. **`srt-tests.webp`** — Terminal test output, resized to 1200×877, WebP, ~60KB
6. **`youtube-growth.webp`** — Analytics panel, resized to 1200×680, WebP, ~70KB
7. **`camera-rig.webp`** — Blackmagic camera photo, resized to 1200×900, WebP, ~100KB
8. **`ai-pipeline.svg`** — Clean vector diagram of your LLM prompt chain. Should be hand-crafted, not auto-generated.
9. **`youtube-growth.svg`** — Clean vector chart showing growth metrics.
10. Logo files — Keep as PNG but optimize through TinyPNG or similar.

**Create a folder structure:**
```
/
├── index.html
├── work.html
├── lab.html
├── style.css
├── main.js
├── Jacob_Britten_Resume.pdf
└── images/
    ├── hero-bg.webp
    ├── headshot.webp
    ├── notion-pipeline.webp
    ├── remotion-code.webp
    ├── srt-tests.webp
    ├── youtube-growth.webp
    ├── camera-rig.webp
    ├── ai-pipeline.svg
    ├── youtube-growth.svg
    ├── HighFunctioningLogo.png
    ├── LamacchiaLogo.png
    └── CrushitLogo.png
```

---

*The rewrite follows in the accompanying code files.*
